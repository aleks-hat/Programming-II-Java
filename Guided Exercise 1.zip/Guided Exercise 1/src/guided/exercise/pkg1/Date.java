/*
 Aleks Hatfield
CS 202
Guided Exercise 1
 */
package guided.exercise.pkg1;

public class Date {
    int month, day, year;
    
    Date(){
        this.month = 1;
        this.day = 1;
        this.year = 2016;
    }
    
    Date(int month, int day, int year){
        this.month = month;
        this.day = day;
        this.year = year;
    }
    
    void setMonth(int month){
        this.month = month;
    }
    
    void setDay(int day){
        this.day = day;
    }
    
    void setYear(int year){
        this.year = year;
    }
    
    int getMonth(){
        return this.month;
    }
    
    int getDay()
    {
        return this.day;
    }
    
    int getYear(){
        return this.year;
    }
}
