/*
Aleks Hatfield
CS 202
 */
package guided.exercise.pkg1;

public class Heater {
    private boolean on;
    private int goalTemp;
    
    public Heater(boolean on, int goalTemp){
        this.on = on;
        this.goalTemp = goalTemp;
    }
    
    public Heater(){
    on = false;
    goalTemp = 68;
}
   public boolean isOn(){
       return on;
   }
   
   public int desiredTemp(){
       return goalTemp;
   }
   
   public void turnOn(){
       on = true;
   }
   
   public void turnOff(){
       on = false;
   }
   
   public void increaseTemp(){
       goalTemp++;
   }
   
   public void decreaseTemp(){
       goalTemp--;
   }
   
   public void setTemp(int goalTemp){
       this.goalTemp = goalTemp;
   }
   
}


