/*
Aleks Hatfield
CS 202
Representing a Heater
 */
package guided.exercise.pkg1;

public class GuidedExercise1 {
    
    public static void main(String[] args) {
        
        System.out.println("Hello World!");
        Heater myHeater = new Heater();
        System.out.println(myHeater.isOn());
        myHeater.setTemp(80);
        System.out.println(myHeater.desiredTemp());
        myHeater.turnOff();
        System.out.println(myHeater.isOn());
        myHeater.increaseTemp();
        myHeater.increaseTemp();
        System.out.println(myHeater.desiredTemp());
        System.out.println("Goodbye");
        
        Date jan1 = new Date();
        System.out.println(jan1.getMonth() + "/" + jan1.getDay() + "/" + jan1.getYear());
        
        Date myDate = new Date(6,7,1995);
        myDate.setMonth(7);
        myDate.setDay(15);
        myDate.setYear(1996);
        
        System.out.println(myDate.getMonth() + "/" + myDate.getDay() + "/" + myDate.getYear());
    }
    
}
