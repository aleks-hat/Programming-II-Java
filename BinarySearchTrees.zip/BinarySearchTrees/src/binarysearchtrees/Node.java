/*
Alex hatfield
CS 202
Node BOYZ
 */
package binarysearchtrees;

public class Node {
    private Node left;
    private Node right; 
    private int value;

    public Node getLeft() {
        return left;
    }

    public void setLeft(Node left) {
        this.left = left;
    }

    public Node getRight() {
        return right;
    }

    public void setRight(Node right) {
        this.right = right;
    }
    
    public Node(int value, Node left, Node right){
    this.value = value;
    this.left = left;
    this.right = right;
 }
}

