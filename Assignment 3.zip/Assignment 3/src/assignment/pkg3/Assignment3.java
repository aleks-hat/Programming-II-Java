/*
Alex Hatfield
CS 202
Assignment 3
 */

package assignment.pkg3;

import java.util.Scanner;
import java.util.Random;

public class Assignment3 {

    public static void main(String[] args) {
       menu();   
    }
    
    public static void phone(){
        System.out.println("Ring Ring");
    }
    
    public static void helloPerson(String person){
        System.out.println("Hello" + " " +  person);
    }
    
    public static String englishMonth(int month){
        if (month == 1){
            return "January";
        }
        
        else if (month == 2){
            return "February";
        }
        
        else if (month == 3){
            return "March";
        }
        
        else if (month == 4) {
            return "April";
        }
        
        else if (month == 5){
            return "May"; 
        }
        
        else if (month == 6){
            return "June";
        }
        
        else if (month == 7){
            return "July";
        }
        
        else if (month == 8){
            return "August"; 
        }
        
        else if (month == 9){
            return "September";
        }
        
        else if (month == 10){
            return "October";
        } 
        
        else if (month == 11){
            return "November";
        }
        
        else if (month == 12){
            return "December";
        }
        
        else {
            return "Error!";
        }
    }
    
 public static boolean isLeapYear(int year){
        if (year % 4 == 0){
            if (year % 100 == 0){
                if (year % 400 == 0){
                    return true;
                }
                return false;
            }
            return true;
        }
        return false;
    }
 
 public static int dayOfWeek(int day, int month, int year){
        
        int step1 = year - (14 - month) / 12;
        int step2 = step1 + step1/4 - step1/100 + step1/400;
        int step3 = month + 12 * ((14 - month) / 12) - 2;
        int result = (day + step2 + (31*step3)/12) % 7;
        
        return result;
 }

public static void calendarMonth( int month , int year){
    
    String month2 = englishMonth(month);
    boolean year2 = isLeapYear(year);
    int day2 = dayOfWeek(month, 1 , year);
    System.out.println("\n");
    System.out.println(month2 + " " + year);
    System.out.println("S  M  T  W  T  F  S ");
    int day2 = 0;
    if(month == 2 && year2 == true){
           day2 = 29;
       }
    
    else if(month == 2 && year2 == false){
           day2 = 28;
       }
    
    else if(month == 9){
           day2 = 30;
       }
    
    else if(month == 4){
           day2 = 30;
       }
    
    else if(month == 11){
           day2 = 30;
       }
    
    else if(month == 6){
           day2 = 30;
       }
    
    else{
           day2 = 31;
       }
    
    int dayOf = 0;
    for(int i = 0; i < day; i++){
        System.out.print("   ");
        dayOf++;
       }
    
    for(int i= 1; i<= day2; i++ ){
        
        if(dayOf == 6 && i < 10){
               System.out.println( "0" + i + " ");
               dayOf++;
           }
        
        else if(dayOf == 13 && i < 10){
               System.out.println("0" + i + " ");
               dayOf++;
           }
        
        else if( dayOf == 13){
               System.out.println(i);
               dayOf++;
           }
        
        else if(dayOf == 20){
               System.out.println(i);
               dayOf++;
           }
        
        else if(dayOf == 27){
               System.out.println(i);
               dayOf++;
           }
        
        else if(dayOf == 34){
               System.out.println(i);
               dayOf++;
           }
        
        else if(i < 10){
               System.out.print("0" + i + " ");
               dayOf++;
           }
        
        else{
               System.out.print(i + " ");
               dayOf++;
           }
           
       }  
       
   }
    
         public static void calendarYear(int year){
             
             for (int i = 1; i <= 12; i++){
                 calendarMonth(i, year);
                 
             }
         }
         
         public static void guessingGame(){
             Scanner in = new Scanner(System.in);
             Random r = new Random();
             boolean playAgain = true;
             while (playAgain == true){
                 int num = r.nextInt(100) + 1;
             int guess = 0; 
             System.out.println(num);
             while(guess != num){
                 System.out.println("Enter your guess");
                 guess = in.nextInt();
                 if (guess < num){
                     System.out.println("Too Low!");
                 }
                 
                 if (guess > num){
                     System.out.println("Too High!");
                 }
                 
                 if (guess == num){
                     System.out.println("Good Job, you got it, yay!");
                 }
                 }
             System.out.println("Wanna play again?");
             in.nextLine();
             String answer = in.nextLine();
             if (answer == "y" || answer == "Y"){
                 playAgain = true;
             }
             
             else {
                 playAgain = false;
                 System.out.println("bye bye");
             }
            
             }   
         }
         
         public static void nim(){
             Random randy = new Random();
             Scanner in = new Scanner(System.in);
             int pile = randy.nextInt(91) + 10;
             int turn = randy.nextInt(2);
             int smart = randy.nextInt(2);
             
             if (smart == 0){
                 System.out.println("This computer is dumb!");
                 //dumb
                 while (pile != 1){
                     if (turn == 0){ //human
                         System.out.println("Number of marbles: " + pile);
                         System.out.println("How many marbles do you want to take? You can chouse between 1 and " + (pile/2));
                         int number = in.nextInt();
                         
                         while (number <1 || number > (pile/2) ) {
                             System.out.println("NO!");
                             System.out.println("Number of marbles: " + pile);
                             System.out.println("How many marbles do you want to take? You can chouse between 1 and " + (pile/2));
                             number = in.nextInt();
                         }
                         
                         pile = pile - number;
                         turn = 1;
                     }
                     if (turn == 1 && pile != 1){
                         int compTurn = randy.nextInt(pile/2) + 1;
                         pile = pile - compTurn;
                         turn = 0;
                     }
                     
                 }
                 
                 if (turn == 1){
                     System.out.println("You won! Congrats");
                 }
                 
                 if (turn == 0){
                     System.out.println("The computer won, sorry.");
                 }      
             }
             
             else if (smart == 1){
                 //smart
                 System.out.println("This computer is smart!");
                 while (pile != 1){
                     if (turn == 0){ //human
                         System.out.println("Number of marbles: " + pile);
                         System.out.println("How many marbles do you want to take? You can chouse between 1 and " + (pile/2));
                         int number = in.nextInt();
                         
                         while (number <1 || number > (pile/2) ) {
                             System.out.println("NO!");
                             System.out.println("Number of marbles: " + pile);
                             System.out.println("How many marbles do you want to take? You can chouse between 1 and " + (pile/2));
                             number = in.nextInt();
                         }
                         
                         pile = pile - number;
                         turn = 1;
                     }
                     if (turn == 1 && pile != 1){
                         int compTurn = 0;
                         if (pile == 1 || pile == 3 || pile == 7 || pile == 15 || pile == 31 || pile == 63){
                             compTurn = randy.nextInt(pile/2) + 1;
                             pile = pile - compTurn;

                         }
                         else if (pile > 63) {
                             pile = 63;
                         } 
                         
                         else if (pile < 63 && pile > 31){
                             pile = 31;
                         }
                         
                         else if (pile < 31 && pile > 15){
                             pile = 15;
                         }
                         
                         else if (pile < 15 && pile > 7){
                             pile = 7;
                         }
                         
                         else if (pile < 7 && pile > 3){
                             pile = 3;
                         }
                         
                         else if (pile < 3 && pile > 1){
                             pile = 1;
                         }
                         
                         turn = 0;
                     }
                     
                 }
                 
                 if (turn == 1){
                     System.out.println("You won! Congrats);
                 }
                 
                 if (turn == 0){
                     System.out.println("The computer won, sorry");
                 }
             }
             
         }
         
         public static void monty(){
             Random montyRan = new Random();
             int strategy1 = 0; //switch
             int strategy2 = 0; //stay
             for (int i = 0; i < 1000; i++){
                 int car = montyRan.nextInt(3);
                 int choice = montyRan.nextInt(3);
                 
                 if (car == choice){
                     strategy2++;
                 }
                 
                 else {
                     strategy1++;
                 }
                 
             }
             
             System.out.println("Strategy 1: " + strategy1);
             System.out.println("Strategy 2: " + strategy2);
             
         }
         
   public static void menu(){
         int choice = 0;
         Scanner in = new Scanner(System.in);

        do{
            System.out.println("\nMake a choice!");
            System.out.println("1.) phone");
            System.out.println("2.) hello person");
            System.out.println("3.) month");
            System.out.println("4.) leap year");
            System.out.println("5.) day of the week");
            System.out.println("6.) calendar");
            System.out.println("7.) caldendar for the year");
            System.out.println("8.) guess the number");
            System.out.println("9.) the game of nim");
            System.out.println("10.) monty bois");
            System.out.println("11.) exit");
            choice = in.nextInt();
            int month =0;
            int day =0; 
            int year = 0;
            switch (choice){
                case 1:
                    phone();
                    break;
                case 2:
                    helloPerson("Aleks");
                    break;
                case 3:
                    System.out.println("Enter a number betwen 1 and 12");
                    month = in.nextInt();
                    System.out.println(englishMonth(month));
                    in.nextLine();
                    break;
                case 4:
                    System.out.println("Enter a year!");
                    year = in.nextInt();
                    System.out.println(isLeapYear(year));
                    in.nextLine();
                    break;
                case 5:
                    System.out.println("Enter a month!");
                    month = in.nextInt();
                    System.out.println("Enter the day of the month!");
                    day = in.nextInt();
                    System.out.println("Enter a year!");
                    year = in.nextInt();
                    System.out.println(dayOfWeek(day, month, year));
                    
                    break;
                case 6:
                    System.out.println("Enter a month!");
                    month = in.nextInt();
                    System.out.println("Enter a year!");
                    year = in.nextInt();
                    calendarMonth(month , year);
                            
                    break;
                case 7:
                    System.out.println("Enter a year!");
                    year = in.nextInt();
                    calendarYear(year);
                    break;
                case 8:
                    guessingGame();
                    break;
                case 9:
                    nim();
                    break;
                case 10:
                    monty();
                    break;
                default:
                    if (choice !=11){
                        System.out.println("NO!");
                    }
            }  
        }while(choice != 11);
    }
   
    }

