/*
 Aleks Hatfield
CS 202
Assignment 1
 */
package assignment.pkg1;

import java.util.Scanner;

public class Assignment1 {

    public static void main(String[] args) {
        
        System.out.println("Aleks Hatfield, I'm a Mathmatics major from Bluefield, WV.  I like food and sleeping, hobbies include eating and sleeping and I have a cat named Casserole.");
        
        int number= 42;
        System.out.println(number);
        
        double decimal= 99.42;
        System.out.println(decimal);
        
        char letter = 'L';
        System.out.println(letter);
        
        String mystring = "I am going to learn java";
        System.out.println(mystring);
        
        boolean myboo = true;
        System.out.println(myboo);
        
        
        Scanner in = new Scanner(System.in);
        System.out.println("Enter a Celsius temperature plz");
        int value = in.nextInt();
        System.out.println("The temperature in Fahrenheit is:" + (value * 9/5 + 32));
        
        System.out.println("Enter a Fahrenheit temperature plz");
        int value2 = in.nextInt();
        System.out.println("The temperature in Celcius is:" + ((value2- 32) * 5/9));
     in.nextLine();
     
         String game = "In my grandmother's trunk I found a ";
         System.out.println("Enter an item");
         String item1 = "";
         item1 = in.nextLine();
         System.out.println(game + item1);
                
         System.out.println("Enter another item");
         String item2 = "";
         item2 = in.nextLine();
         System.out.println(game + item1 + " " + "and a " + item2);
                
         System.out.println("Enter another item");
         String item3 = "";
         item3 = in.nextLine();
         System.out.println(game + item1 + ", " + item2 + ", and a " + item3);
                
         System.out.println("Enter another item");
         String item4 = "";
         item4 = in.nextLine();
         System.out.println(game + item1 + ", " + item2 + ", " + item3 + ", and a " + item4);
                
         System.out.println("Enter another item");
         String item5 = "";
         item5 = in.nextLine();
         System.out.println(game + item1 + ", " + item2 + ", " + item3 + ", " + item4 + ", and a " + item5);
                
        String bodmass = "Enter weight in pounds:";
        System.out.println(bodmass);
        double weight = in.nextDouble();
        String bodheight = "Enter height in inches: ";
        System.out.println(bodheight);
        double height = in.nextDouble();
        double bmi = ((weight * 703)/(height * height));
        System.out.println("Your BMI is: " + bmi);
 
    }


}
