/*
Aleks Hatfield
CS 202
Guided Exercise 2
 */
package guided.exercise.pkg2;

import java.util.Scanner;
import java.util.Random;

public class GuidedExercise2 {

  
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int choice = 0;
        do{
            System.out.println("\nmenu choice");
            System.out.println("1.) while loop");
            System.out.println("2.) for loop");
            System.out.println("3.) do while loop");
            System.out.println("4.) beer on the wall");
            System.out.println("5.) dice roll");
            System.out.println("6.) fizzbuzz");
            System.out.println("7.) counting");
            System.out.println("8.) exit");
            choice = in.nextInt();
            switch (choice){
                case 1:
                    whileLoop();
                    break;
                case 2:
                    forLoop();
                    break;
                case 3:
                    doWhile();
                    break;
                case 4:
                    beer();
                    break;
                case 5:
                    diceRoll();
                    break;
                case 6:
                    FizzBuzz();
                    break;
                case 7:
                    counting();
                    break;
                case 8:
                    break;
                default:
                    System.out.println("Not a good number!");
            }  
        }while(choice != 8);
        
    }
    
    public static void whileLoop(){
        Scanner in = new Scanner(System.in);
        System.out.println("Enter a positve integer");
        int count = 1;
        int value = in.nextInt();
        
        while (value < 0) {
              System.out.println("Error: enter a positive number "); 
              value = in.nextInt();
          }
        
        while( count <= value ) { 
            System.out.print(count);
            System.out.print("\n");
            count++;
        }
    }
    
    public static void forLoop(){
        Scanner in = new Scanner(System.in);
        System.out.println("Enter a positve integer");
        int value = in.nextInt();
        
        while (value < 0) {
              System.out.println("Error: enter a positive number"); 
              value = in.nextInt();
        }
        
        for (int i = 1; i <= value; i++) {
          System.out.println(i);
        }
    }
    
    public static void doWhile(){
        Scanner in = new Scanner(System.in);
        System.out.println("Enter a positve integer");
        int count = 1;
        int value = in.nextInt();
        
        while (value < 0) {
              System.out.println("Error: enter a positive number"); 
              value = in.nextInt();
        }

        do
        {
            System.out.println(count);
            count++;
        } while (count <= value);    
    }
    
    
    public static void beer(){
        
        Scanner in = new Scanner(System.in);
        
        System.out.println("Enter a positive integer");
        int count = 0;
        int value = in.nextInt();
        
        while(count <= value ) {
            System.out.print("\n");

            if(value == 1)
            {
                    System.out.print(value + " bottle of beer on the wall");
            }
            else if(value == 0)
            {
                    System.out.print("No more beer");
            }
            else {
                System.out.print(value + " bottles of beer on the wall");
            }
            value--; 
      }
    }
    
    public static void diceRoll(){
        
        Random sixSided;
        sixSided = new Random();
        System.out.print("\n");
        
        int dieRoll = 0;
        int num1 = 0;
        int num2 = 0;
        int num3 = 0;
        int num4 = 0;
        int num5 = 0;
        int num6 = 0;
        for (int i = 1; i <= 1000; i++) {
           dieRoll = sixSided.nextInt(6)+1;
           if (dieRoll == 1){
               num1++;
           }
           else if (dieRoll == 2){
               num2++;
           }
            else if (dieRoll == 3){
               num3++;
           }
            else if (dieRoll == 4){
               num4++;
            }
            else if (dieRoll == 5){
               num5++;
           }
            else if (dieRoll == 6){
               num6++;
           }
           }
        System.out.println("Number of ones: " + num1);
        System.out.println("Number of twos: " + num2);
        System.out.println("Number of threes: " + num3);
        System.out.println("Number of fours: " + num4);
        System.out.println("Number of fives: " + num5);
        System.out.println("Number of sixes: " + num6);
    }
    
    public static void FizzBuzz(){
        for(int i = 1; i <= 100; i++) {
            if (((i % 5) == 0) && ((i % 3) == 0))
                System.out.print("fizzbuzz");
            else if ((i % 3) == 0) System.out.print("fizz"); 
            else if ((i % 5) == 0) System.out.print("buzz"); 
            else System.out.print(i);
            System.out.print(" "); 
        }
    }
    
    public static void counting(){
        Scanner in = new Scanner(System.in);
        System.out.println("Enter a positive integer");
        int number = in.nextInt();
        int min = number;
        int max = number;
        float sum = number;
        int count = 1;
        while (number >= 0) {
            if (number > max)
                max = number;
            if (number < min) 
                min = number;
            sum += number;
            count++;
            System.out.println("Enter another positive integer");
            number = in.nextInt();
        }

            System.out.println("Max: " + max + " Min: " + min + " Average: " + sum/count);
    }
}