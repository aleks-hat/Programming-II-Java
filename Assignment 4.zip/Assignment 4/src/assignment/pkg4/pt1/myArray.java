/*
Alex Hatfield
CS 202
 */
package assignment.pkg4.pt1;

import java.util.Random;
public class myArray {
    private int[] array;
    
    public myArray(int size){
        array = new int[size];
    }
    
    public int getSize(){
        return array.length;
    }
    
    public int getValue(int i){
        return array[i];
    }
    
    public void wipe(){
        for (int i = 0; i < array.length; i++)
            array[i] = 0;
    }
    
    public boolean isEmpty(){
        for (int i = 0; i < array.length; i++)
            if (array[i] != 0)
                return false;
        return true;        
    }
    
    public void makeRandom(int r){
        Random rand = new Random();
        for (int i = 0; i < array.length; i++)
            array[i] = rand.nextInt(r) + 1;
    }
    
    public void assignValue(int i, int v){
        array[i] = v;
    }
    
    public double average(){
        double sum = 0.0;
        for (int i = 0; i < array.length; i++)
            sum += array[i];
        return sum/array.length;
    }
    
    public int largest(){
        int max = array[0];
        for (int i = 0; i < array.length; i++)
            if (array[i] > max)
                max = array[i];
        return max;
    }
    
    public int smallest(){
        int small = array[0];
        for (int i = 0; i < array.length; i++)
            if (array[i] < small)
                small = array[i];
        return small;
    }
    
    public int difference(){
        int small = this.smallest();
        int max = this.largest();
        return max - small;
    }
    
    public void reverse(){
        int[] temp = new int[array.length];
        for (int i = 0; i < array.length; i++)
            temp[array.length-i-1] = array[i];
        array = temp;
    }
    
    public void print(){
        for (int i = 0; i < array.length; i++)
            System.out.print(array[i] + " ");
    }
    
    public void bubbleSort(){
        boolean swapped = true;
        while (swapped) {
            swapped = false;
            for(int i=1; i<array.length; i++) {
                int current=0;
                if(array[i-1] > array[i]) {
                    current = array[i-1];
                    array[i-1] = array[i];
                    array[i] = current;
                    swapped = true;
                }
            }
        }
    }
    
    public void selectionSort(){
        for (int top = 0; top < array.length; top++){
            int smallest = top;
            for (int i = top; i < array.length; i++){
                if (array[i] < array[smallest]){
                    smallest = i;
                }
            }
            int temp = array[top];
            array[top] = array[smallest];
            array[smallest] = temp;
        }
    }
    
    public void insertionSort(){
        for (int i = 1; i < array.length; i++){
            for (int j = i; j > 0 && array[j-1] > array[j]; j--){
                int temp = array[j-1];
                array[j-1] = array[j];
                array[j] = temp;
            }
        }
    }
    
    public void fisherYates(){
        for (int i = array.length - 1; i > 0; i--){
            Random r = new Random();
            int n = r.nextInt(i+1);
            int temp = array[i];
            array[i] = array[n];
            array[n] = temp;
        }
    }
    
    public int linearSearch(int n){
        for (int i = 0; i < array.length; i++){
            if (array[i] == n)
                return i;
        }
        return -1;
    }
    
    public int binarySearch(int n){
        //I got bb to help me with dis one
        selectionSort();
        int bottom = 0;
        int top = array.length - 1;
        while (bottom <= top){
            int i = (bottom + top) / 2;
            if (array[i] == n)
                return i;
            else if (array[i] > n){
                top = i - 1;
            }
            else if (array[i] < n){
                bottom = i + 1;
            }
        }
        return -1;
    }
}
