/*
Alex Hatfield
CS 202
Array shiz
 */
package assignment.pkg4.pt1;

import java.util.Scanner;

public class Assignment4Pt1 {

    public static void main(String[] args) {
        myArray notMyArray = new myArray(5);
        
        boolean exit = false;
        do{
            System.out.println("1.) get size");
            System.out.println("2.) get value");
            System.out.println("3.) wipe array");
            System.out.println("4.) is empty?");
            System.out.println("5.) make random");
            System.out.println("6.) assign value");
            System.out.println("7.) average");
            System.out.println("8.) largest");
            System.out.println("9.) smallest");
            System.out.println("10.) difference");
            System.out.println("11.) reverse");
            System.out.println("12.) print");
            System.out.println("13.) bubble sort");
            System.out.println("14.) selection sort");
            System.out.println("15.) insertion sort");
            System.out.println("16.) fisher yates shuffle");
            System.out.println("17.) linear search");
            System.out.println("18.) binary search");
            System.out.println("19.) exit");

            int choice = getUserIn("option");
            switch (choice){
                case 1:
                    System.out.println(notMyArray.getSize());
                    break;
                case 2:
                    choice = getUserIn("what place?");
                    System.out.println(notMyArray.getValue(choice));
                    break;
                case 3:
                    notMyArray.wipe();
                    break;
                case 4:
                    System.out.println(notMyArray.isEmpty());
                    break;
                case 5:
                    choice = getUserIn("what random do you want?");
                    notMyArray.makeRandom(choice);
                    break;
                case 6:
                    int place = getUserIn("what place?");
                    int value = getUserIn("what number?");
                    notMyArray.assignValue(place, value);
                    break;
                case 7:
                    System.out.println(notMyArray.average());
                    break;
                case 8:
                    System.out.println(notMyArray.largest());
                    break;
                case 9:
                    System.out.println(notMyArray.smallest());
                    break;
                case 10:
                    System.out.println(notMyArray.difference());
                    break;
                case 11:
                    notMyArray.reverse();
                    break;
                case 12:
                    for (int i = 0; i < notMyArray.getSize(); i++)
                        System.out.println(notMyArray.getValue(i));
                    break;
                case 13:
                    notMyArray.bubbleSort();
                    break;
                case 14:
                    notMyArray.selectionSort();
                    break;
                case 15:
                    notMyArray.insertionSort();
                    break;
                case 16:
                    notMyArray.fisherYates();
                    break;
                case 17:
                    choice = getUserIn("what number?");
                    int location = notMyArray.linearSearch(choice);
                    if (location >= 0){
                        System.out.println(choice + " is at " + location);
                    }
                    else {
                        System.out.println(choice + " is not in the array :(");
                    }
                    break;
                case 18:
                    choice = getUserIn("what number?");
                    location = notMyArray.binarySearch(choice);
                    if (location >= 0){
                        System.out.println(choice + " is at " + location);
                    }
                    else{
                        System.out.println(choice + " is not in the array :(");
                    }
                    break;
                case 19:
                    exit = true;
                    break;
                default:
                    System.out.println("not allowed, try again");
            }
        }while(!exit);

    }
 
    public static int getUserIn(String s){
        Scanner in = new Scanner(System.in);
        System.out.println(s);
        int input = in.nextInt();
        return input;
    }
}