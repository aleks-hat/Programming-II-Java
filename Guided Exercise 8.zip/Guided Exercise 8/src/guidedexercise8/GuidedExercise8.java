/*
Aleks Hatfield
CS 202
 */
package guidedexercise8;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;


public class GuidedExercise8 {

 
    public static void main(String[] args) {


    }
    
    public static void counter(){
        
    }
    
}
