/*
Alex Hatfield
CS 202
is checkers board
 */
package checkersproject;

/**
 *
 * @author Aleks
 */
public class board {
    private char[][] squares;

    public board (int size){
        squares = new char[size][size];
        for(int i = 0; i < size; i++){
            for(int j = 0; j < size; j++){
                squares[i][j] = ' ';
            }
        }
    }
    
    public void pieces(){
        char[] row = squares[0];
        int i = 0;
        while(i < row.length){
            squares[0][i] = 'R';
            i = i + 2;
        }
        
        row = squares[1];
        i = 1;
        while(i < row.length){
            squares[1][i] = 'R';
            i = i + 2;
        }
        
        row = squares[squares.length - 2];
        i = 0;
        while(i < row.length){
            squares[squares.length - 2][i] = 'B';
            i = i + 2;
        }
        
        row = squares[squares.length - 1];
        i = 1;
        while(i < row.length){
            squares[squares.length - 1][i] = 'B';
            i = i + 2;
        }
    }
    
    public void printBoard(){
        for(int i = 0; i < squares.length; i++){
            System.out.print("|");
            for(int j = 0; j < squares.length; j++){
                System.out.print(squares[i][j] + "|");
            }
            System.out.println();
        }
        
    }
    
}


