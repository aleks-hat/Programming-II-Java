/*
Alex Hatfield
CS 202
This is a checkers.
 */
package checkersproject;

/**
 *
 * @author Aleks
 */
public class CheckersProject {

    public static void main(String[] args) {
        board boardboyz = new board(8);
        boardboyz.pieces();
        boardboyz.printBoard();
    }
    
}
