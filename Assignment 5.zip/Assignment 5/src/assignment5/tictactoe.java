/*
Aleks Hatfield
Tic Tac Toe
 */
package assignment5;

import java.util.Scanner;
import java.util.Random;

public class tictactoe {
    char board[][];
    int turn;
    
    public tictactoe(){
        board = new char[3][3];
        wipe();
        turn = 1;
    }
    
    public int play(int players){
        if (players == 1){
            return playWithComputer();
        }
        else{
            return playWithFriend();
        }
    }
    
    private int playWithComputer(){
        wipe();
        turn = 1;
        while(true){
            printBoard();
            if (checkForWin() > 0)
                break;
            
            else if (checkForTie())
                return -1;
            
            if (turn == 1){
                System.out.println("player 1 turn");
                boolean validChoice = false;
                int row, col = 0;
                do{
                    row = getUserIn("which row would you like?");
                    col = getUserIn("which column would you like?");
                    if (row > 2 || col > 2 || row < 0 || col < 0)
                        System.out.println("invalid choice! try again, bb");
                    else if (board[row][col] != ' ')
                        System.out.println("spot's filled already. try again");
                    else
                        validChoice = true;
                } while(validChoice == false);
                
                board[row][col] = 'x';
                turn++;
            }
            
            else{
                System.out.println("player 2 turn");
                Random r = new Random();
                int row = r.nextInt(3);
                int col = r.nextInt(3);
                while (board[row][col] != ' '){
                    row = r.nextInt(3);
                    col = r.nextInt(3);
                }
                
                board[row][col] = 'o';
                turn--;
            }
        }
        
        return checkForWin();
    }
    
    private int playWithFriend(){
        wipe();
        turn = 1;
        while(true){
            printBoard();
            if (checkForWin() > 0)
                break;
            
            else if (checkForTie())
                return -1;
            
            if (turn == 1){
                System.out.println("player 1");
                boolean validChoice = false;
                int row, col = 0;
                do{
                    row = getUserIn("which row would you like?");
                    col = getUserIn("which column would you like?");
                    if (row > 2 || col > 2 || row < 0 || col < 0)
                        System.out.println("invalid choice! try again.");
                    else if (board[row][col] != ' ')
                        System.out.println("spot's filled already. try again");
                    else
                        validChoice = true;
                } while(validChoice == false);
                
                board[row][col] = 'x';
                turn++;
            }
            
            else{
                System.out.println("player 2");
                boolean validChoice = false;
                int row, col = 0;
                do{
                    row = getUserIn("which row would you like?");
                    col = getUserIn("which column would you like?");
                    if (row > 2 || col > 2 || row < 0 || col < 0)
                        System.out.println("invalid choice! try again.");
                    else if (board[row][col] != ' ')
                        System.out.println("spot's filled already. try again");
                    else
                        validChoice = true;
                } while(validChoice == false);
                
                board[row][col] = 'o';
                turn--;
            }
        }
        
        return checkForWin();
    }
    
    private void printBoard(){
        System.out.println("   0 1 2");
        System.out.println("  ------");
        for (int i = 0; i < 3; i++){
            System.out.print(i + "|");
            for (int j = 0; j < 3; j++){
                System.out.print(" " + board[i][j]);
            }
            System.out.println();
        }
    }
    
    private void wipe(){
        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 3; j++)
                board[i][j] = ' ';
    }
    
    private int checkForWin(){
        for (int i = 0; i < 3; i++){
            if (board[i][0] == 'x' && board[i][1] == 'x' && board[i][2] == 'x')
                return 1;
            if (board[i][0] == 'o' && board[i][1] == 'o' && board[i][2] == 'o')
                return 2;
            if (board[0][i] == 'x' && board[1][i] == 'x' && board[2][i] == 'x')
                return 1;
            if (board[0][i] == 'o' && board[1][i] == 'o' && board[2][i] == 'o')
                return 2;
        }
        
        if (board[0][0] == 'x' && board[1][1] == 'x' && board[2][2] == 'x')
            return 1;
        else if (board[0][2] == 'x' && board[1][1] == 'x' && board[2][0] == 'x')
            return 1;
        else if (board[0][0] == 'o' && board[1][1] == 'o' && board[2][2] == 'o')
            return 2;
        else if (board[0][2] == 'o' && board[1][1] == 'o' && board[2][0] == 'o')
            return 2;
        else
            return -1;
    }
    
    private boolean checkForTie(){
        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 3; j++)
                if (board[i][j] == ' ')
                    return false;
        return true;
    }
    
    private int getUserIn(String s){
        Scanner in = new Scanner(System.in);
        System.out.println(s);
        return in.nextInt();
    }
}
