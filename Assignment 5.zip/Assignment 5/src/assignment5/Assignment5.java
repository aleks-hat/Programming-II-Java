/*
Aleks Hatfield
CS 202
Tic Tac Toe
 */
package assignment5;

import java.util.Scanner;

public class Assignment5 {

    public static void main(String[] args) {
        tictactoe test = new tictactoe();
        int player1Score = 0;
        int player2Score = 0;
        int ties = 0;
        int result = 0;
        int choice = 0;
        boolean exit = false;
        do{
            System.out.println("tic tac toe");
            System.out.println("1.) play a technomachine (computer is player 2)");
            System.out.println("2.) play a friend (friend is player 2)");
            System.out.println("3.) view scores");
            System.out.println("4.) exit");
            
            choice = getUserIn("what choice bb?");
            
            switch (choice){
                case 1:
                    result = test.play(1);
                    if (result == 1){
                        player1Score++;
                        System.out.println("player 1 wins");
                    }
                    
                    else if (result == 2){
                        player2Score++;
                        System.out.println("player 2 wins");
                    }
                    
                    else{
                        ties++;
                        System.out.println("tie");
                    }
                        
                    break;
                case 2:
                    result = test.play(2);
                    if (result == 1){
                        player1Score++;
                        System.out.println("player 1 wins");
                    }
                    
                    else if (result == 2){
                        player2Score++;
                        System.out.println("player 2 wins");
                    }
                    
                    else{
                        ties++;
                        System.out.println("tie");
                    }
                    break;
                case 3:
                    System.out.println("Player 1 wins: " + player1Score);
                    System.out.println("Player 2 wins: " + player2Score);
                    System.out.println("Ties: " + ties);
                    break;
                case 4:
                    exit = true;
                    break;
                default:
                    System.out.println("bad choice, try again");
            }
        }while (!exit);
        
    }
    
    public static int getUserIn(String s){
        Scanner in = new Scanner(System.in);
        System.out.println(s);
        return in.nextInt();
    }
    
}
