/*
Aleks Hatfield
CS 202
2D 
 */
package guidedexercise5;

import java.util.InputMismatchException;
import java.util.Scanner;

public class my2DPoint {
    
    private int x;
    private int y;
    
    public my2DPoint(int x, int y){
        this.x = x;
        this.y = y;
    }
    
    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }
    
    public String toString(){
        Scanner in = new Scanner(System.in);
try{
            System.out.print("Enter an integer: ");
            x = in.nextInt();
            System.out.println("Enter another integer: ");
            y = in.nextInt();
}
catch (InputMismatchException e){
    System.out.println("oops try again");
    System.exit(0);
}
            
            return "(" + x + "," + y + ")";
        }
      

}
