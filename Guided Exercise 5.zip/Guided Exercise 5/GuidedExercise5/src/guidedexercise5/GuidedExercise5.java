/*
 Aleks Hatfield
CS 202
Composition
 */
package guidedexercise5;

import java.util.Scanner;

public class GuidedExercise5 {
   
    public static void main(String[] args) {
  
        my2DPoint notMyPoint = new my2DPoint(0,0);
        System.out.println(notMyPoint.toString());
        
        Turtle todd = new Turtle(0,0,0);
        
        int choice = 0;
        Scanner in = new Scanner(System.in);
        do{
            System.out.println("Turtles!");
            System.out.println("Move todd the turtle");
            System.out.println("1.) Move forward");
            System.out.println("2.) Turn right");
            System.out.println("3.) Move Randomly");
            System.out.println("4.) Exit");
            choice = in.nextInt();
            switch (choice){
                    case 1:
                        todd.forward();
                        System.out.println(todd.getPosition());
                        break;
                    case 2:    
                        todd.turnRight();
                        System.out.println(todd.getPosition());
                        break;
                    case 3:
                        System.out.println("Enter a number");
                        int x = in.nextInt();
                        todd.randomTodd(x);
                                
                        break;
                    case 4:
                        break;
                    default:
                        System.out.println("invalid, try again");
                }
            } while (choice != 4 );
   
    }
    
}
