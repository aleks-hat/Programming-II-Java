/*
Aleks Hatfield
CS 202
I like turtles. Todd can do anything he sets his mind to.
 */
package guidedexercise5;

import java.util.Random;

public class Turtle {
    private int direction;
    private my2DPoint location;

    public Turtle(int x, int y, int direction){
        location = new my2DPoint(x, y);
        this.direction = direction;
    }
    
     public String getLocation(){
         return location.toString();
     }
     
     public void forward(){
         if(getDirection() == 0){
             location.setY(location.getY() + 1);
         }
         else if (getDirection() == 1){
             location.setX(location.getX() + 1);
         }
         else if (getDirection() == 2){
             location.setY(location.getY() - 1);
         }
         else if (getDirection() == 3){
             location.setX(location.getX() - 1);
         } 
     }
     
     public void turnRight(){
         if (getDirection() == 3){
             direction = 0;
         }
         else{
             direction++;
         }

     }
     
     public String getPosition(){
         return "(" + location.getX() + "," + location.getY() + ")";
         
     }
     
    public int getDirection() {
        return direction;
    }

    public void setDirection(int direction) {
        this.direction = direction;
    }

    
    public void randomTodd(int x){
        Random r = new Random();
        while(x > 0){
            int randick = r.nextInt(2);
            if (randick == 0){
                forward();
            }
            else {
                turnRight();
            }
            x--;
            System.out.println(getPosition());
        }
    }
}

