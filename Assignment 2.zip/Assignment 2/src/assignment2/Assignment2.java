/*
Alex Hatfield 
CS 202
Assignment 2
 */
package assignment2;

import java.util.Scanner;

public class Assignment2 {

 
    public static void main(String[] args) {
        int choice = 0;
        Scanner in = new Scanner(System.in);
        do{
            System.out.println("Assignment 2 yay!");
            System.out.println("Pick a choice below.");
            System.out.println("1.) Enter a date");
            System.out.println("2.) Shake the magic 8 ball");
            System.out.println("3.) Exit");
            choice = in.nextInt();
            switch (choice){
                case 1:
                    Date date = getValidDate();
                    getDayAndSeason(date);
                    break;
                case 2:    
                    Magic8Ball m = new Magic8Ball();
                    System.out.println(m.shake());
                    break;
                case 3:
                    break;
                default:
                    System.out.println("Invalid choice, try again!");
            }
        }while (choice != 3 );
    }
    
    /*I got help all throughout this section, partically with the logic of 
    checking the date for being valid*/
    public static Date getValidDate(){
        Scanner scan = new Scanner(System.in);
        Date date;
        boolean valid = false;
        
        do{
            System.out.print("Please enter a month: ");
            int month = scan.nextInt();
            System.out.print("Please enter a day: ");
            int day = scan.nextInt();
            System.out.print("Please enter a year: ");
            int year = scan.nextInt();

            date = new Date(month, day, year);
            if (checkNums(date) && checkMonth(date) && checkDay(date)){
                valid = true;
            }
        } while(!valid);
        
        return date;
    }
    
    public static boolean checkNums(Date date){
        if (date.getMonth() < 1 || date.getDay() < 1 || date.getYear() < 0){
            System.out.println("Members of date class cannot be zero or negative!");
            return false;
        } else {
            return true;
        }
    }
    
    public static boolean checkMonth(Date date){
        if (date.getMonth() > 12){
            System.out.println("Month must be between 1 and 12!");
            return false;
        } else {
            return true;
        }
    }
    
    public static boolean checkDay(Date date){
        boolean isLeapYear = checkLeapYear(date);
        int day = date.getDay();
        
        switch (date.getMonth()){
            case 1:
                if (day <= 31){
                    return true;
                } else {
                    System.out.println("January only has 31 days!");
                    return false;
                }
            case 2:
                if (day <= 28){
                    return true;
                } else if (day == 29 && isLeapYear) {
                    return true;
                } else {
                    System.out.println("February only has 28 days (or 29 on a leap year)!");
                    return false;
                }
            case 3:
                if (day <= 31){
                    return true;
                } else {
                    System.out.println("March only has 31 days!");
                    return false;
                }
            case 4:
                if (day <= 30){
                    return true;
                } else {
                    System.out.println("April only has 30 days!");
                    return false;
                }
            case 5:
                if (day <= 31){
                    return true;
                } else {
                    System.out.println("May only has 31 days!");
                    return false;
                }
            case 6:
                if (day <= 30){
                    return true;
                } else {
                    System.out.println("June only has 30 days!");
                    return false;
                }
            case 7:
                if (day <= 31){
                    return true;
                } else {
                    System.out.println("July only has 31 days!");
                    return false;
                }
            case 8:
                if (day <= 31){
                    return true;
                } else {
                    System.out.println("August only has 31 days!");
                    return false;
                }
            case 9:
                if (day <= 30){
                    return true;
                } else {
                    System.out.println("September only has 30 days!");
                    return false;
                }
            case 10:
                if (day <= 31){
                    return true;
                } else {
                    System.out.println("October only has 31 days!");
                    return false;
                }
            case 11:
                if (day <= 30){
                    return true;
                } else {
                    System.out.println("November only has 30 days!");
                    return false;
                }
            case 12:
                if (day <= 31){
                    return true;
                } else {
                    System.out.println("December only has 31 days!");
                    return false;
                }
            default:
                System.out.println("Invalid month!");
                return false;
        }
    }
    
    public static boolean checkLeapYear(Date date){
        int year = date.getYear();
        if (year % 4 == 0){
            if (year % 100 == 0){
                if (year % 400 == 0){
                    return true;
                }
                return false;
            }
            return true;
        }
        return false;
    }
    
    public static void getDayAndSeason(Date date){
        
        int day = date.getDay();
        int month = date.getMonth();
        int year = date.getYear();
        
        int step1 = year - (14 - month) / 12;
        int step2 = step1 + step1/4 - step1/100 + step1/400;
        int step3 = month + 12 * ((14 - month) / 12) - 2;
        int result = (day + step2 + (31*step3)/12) % 7;
        
        String resultStr = "";
        
        switch (result){
            case 1:
                resultStr = "Monday";
                break;
            case 2:
                resultStr = "Tuesday";
                break;
            case 3:
                resultStr = "Wednesday";
                break;
            case 4:
                resultStr = "Thursday";
                break;
            case 5:
                resultStr = "Friday";
                break;
            case 6:
                resultStr = "Saturday";
                break;
            case 7:
                resultStr = "Sunday";
                break;
        }
        
        if (month == 1)
            System.out.println("January " + day + ", " + year + " is a " + resultStr );
        else if (month == 2)
            System.out.println("Febuary " + day + ", " + year + " is a " + resultStr);
        else if (month == 3)
            System.out.println("March " + day + ", " + year + " is a " + resultStr);
        else if (month == 4)
            System.out.println("April " + day + ", " + year + " is a " + resultStr);
        else if (month == 5)
            System.out.println("May " + day + ", " + year + " is a " + resultStr);
        else if (month == 6)
            System.out.println("June " + day + ", " + year + " is a " + resultStr);
        else if (month == 7)
            System.out.println("July " + day + ", " + year + " is a " + resultStr);
        else if (month == 8)
            System.out.println("August " + day + ", " + year + " is a " + resultStr);
        else if (month == 9)
            System.out.println("September " + day + ", " + year + " is a " + resultStr);
        else if (month == 10)
            System.out.println("October " + day + ", " + year + " is a " + resultStr);
        else if (month == 11)
            System.out.println("November " + day + ", " + year + " is a " + resultStr);
        else if (month == 12)
            System.out.println("December " + day + ", " + year + " is a " + resultStr);
        
        if ( (month == 1) || (month == 2))
            System.out.println("It is in the Winter");
        else if ( (month == 4) || (month == 5))
            System.out.println("It is in the Spring");
        else if ( (month == 7) || (month == 8))
            System.out.println("It is in the Summer");
        else if ( (month == 10)|| (month == 11))
            System.out.println("It is in the Fall");
        else if ( (month == 3) && (day <= 19 ))
            System.out.println("It is in the Winter");
        else if ( (month == 3) && (day >= 20 ))
            System.out.println("It is in the Spring");
        else if ( (month == 6) && (day <= 20 ))
            System.out.println("It is in the Spring");
        else if ( (month == 6) && (day >= 21 ))
            System.out.println("It is in the Summer");
        else if ( (month == 9) && (day <= 20 ))
            System.out.println("It is in the Summer");
        else if ( (month == 9) && (day >= 21 ))
            System.out.println("It is in the Autumn");
        else if ( (month == 12) && (day <= 21 ))
            System.out.println("It is in the Autumn");
        else if ( (month == 12) && (day >= 22 ))
            System.out.println("It is in the Winter");
     
    }
    
}
