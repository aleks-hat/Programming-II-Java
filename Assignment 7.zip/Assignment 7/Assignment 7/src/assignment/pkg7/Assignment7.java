/*
Alex Hatfield
CS 202
Binary Search Trees
 */
package assignment.pkg7;

public class Assignment7 {

    public static void main(String[] args) {

            BinarySearchTrees barney = new BinarySearchTrees(69);
            
            barney.Insert(48);
            barney.Insert(5);
            barney.Insert(96);
            barney.Insert(20);
            
            System.out.println(barney.Exists(5));
            System.out.println(barney.Exists(50));
            
            barney.inOrder();
            barney.preOrder();
            barney.postOrder();
            
            barney.delete(96);
            barney.delete(5);
            
            barney.inOrder();
            
            barney.Insert(20);
            
            barney.inOrder();
    }
    
}
