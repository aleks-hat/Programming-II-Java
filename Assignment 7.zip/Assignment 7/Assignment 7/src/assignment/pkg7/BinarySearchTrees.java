/*
Alex Hatfield
CS 202
Trees
 */
package assignment.pkg7;

public class BinarySearchTrees {
    private Node root;
    
    public BinarySearchTrees(int info){
        root = new Node(info, null, null);
    }
            
    public void Insert(int info){
        Insert(info, root);
    }
            
    
    private void Insert(int info, Node node){
        if(node.getInfo() == info){
            return;
        }
        else if (node.getInfo() > info){
            if(node.getLeft() == null){
                node.setLeft(new Node(info, null, null));
            }
            else 
                Insert(info,node.getLeft());
        }
        else if (node.getInfo() < info){
            if (node.getRight() == null){
                node.setRight(new Node(info, null, null));
            }
            else
                Insert(info,node.getRight());
        }
    }
    
    public boolean Exists(int info){
        return Exists(info, root);
    }
    
    private boolean Exists(int info, Node node){
        if(node.getInfo() == info){
            return true;
        }

        else if (node.getInfo() > info){
            if(node.getLeft() == null){
                return false;
            }
        
            else 
                return Exists(info, node.getLeft());
        }

        else if (node.getInfo() < info){
            if (node.getRight() == null){
                return false;
            }
            else
               return Exists(info,node.getRight());
        }
        
        else {
            return false;
        }
    }

    //I got help with the recursive travesals 
    public void inOrder(){
        System.out.print("In-Order: ");
        inOrder(root);
        System.out.println();
    }
    
    private void inOrder(Node node){
        if(node == null){
            return;
        }
        inOrder(node.getLeft());
        System.out.print(node.getInfo() + ", ");
        inOrder(node.getRight());
    }
    
    public void preOrder(){
        System.out.print("Pre-Order: ");
        preOrder(root);
        System.out.println();
    }
    
    private void preOrder(Node node){
        if(node == null){
            return;
        }
        System.out.print(node.getInfo() + ", ");
        preOrder(node.getLeft());
        preOrder(node.getRight());
    }
    
    public void postOrder(){
        System.out.print("Post-Order: ");
        postOrder(root);
        System.out.println();
    }
    
    private void postOrder(Node node){
        if(node == null){
            return;
        }
        postOrder(node.getLeft());
        postOrder(node.getRight());
        System.out.print(node.getInfo() + ", ");
    }
    
    
    /*I could not remember how to do deletes, so I looked up source code
    * for it. We took the code from:
    * http://www.algolist.net/Data_structures/Binary_search_tree/Removal
    * and modified it to work.
    */
    public void delete(int info){
        delete(info, root, null);
    }
    
    private void delete(int info, Node node, Node parent){
        //if the data to delete is left than the current node's value...
        if (info < node.getInfo()){
            //if the node has a left child...
            if (node.getLeft() != null){
                //...delete the value from the left subtree
                delete(info, node.getLeft(), node);
            }
            
            //otherwise, the value doesn't exist in the tree... lame-o.
            else{
                return;
            }
        } 
        
        //if the data to delete is greater than the current node's value...
        else if (info > node.getInfo()){
            //if the node has a right child...
            if (node.getRight() != null){
                //...delete the value from the right subtree
                delete(info, node.getRight(), node);
            }
            
            //otherwise, the value doesn't exist in the tree... baka
            else{
                return;
            }
        }
        
        //otherwise, we have the node to delete.
        else{
            //if the node has two children...
            if (node.getLeft() != null && node.getRight() != null){
                //...replace node's value with minimum value in right subtree
                node.setInfo(findMin(node.getRight()));
                //...and delete the duplicate node in the right subtree
                delete(node.getInfo(), node.getRight(), node);
            }
            
            //otherwise, if the node to delete is a left child of the parent...
            else if (parent.getLeft() == node){
                //...and if the node doesn't have a left child...
                if (node.getLeft() == null){
                    //set the parent's left child to the node's right child
                    parent.setLeft(node.getRight());
                }
                
                //otherwise...
                else{
                    //set the parent's left child to the node's left child
                    parent.setLeft(node.getLeft());
                }
            }
            
            //otherwise, if the node to delete is a right child of the parent...
            else if (parent.getRight() == node){
                //...and if the node doesn't have a left child...
                if (node.getLeft() == null){
                    //set the parent's right child to the node's right child
                    parent.setRight(node.getRight());
                }
                
                //otherwise...
                else{
                    //set the parent's right node to the node's left child
                    parent.setRight(node.getLeft());
                }
            }
        }
    }
    
    private int findMin(Node node){
        if (node.getLeft() != null){
            return findMin(node.getLeft());
        }
        
        else{
            return node.getInfo();
        }
    }
}

